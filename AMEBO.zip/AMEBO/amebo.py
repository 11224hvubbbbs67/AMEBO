import amebo1

amebo1.password()
