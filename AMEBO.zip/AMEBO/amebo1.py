import os
import sys
import requests
import time

red = "\033[0;31m"
blue = "\033[0;34m"
green = "\033[0;32m"
black = "\033[0;30m"

def hokok():
	print(blue+"""
	..............
	            ..,;:ccc,.
	          ......''';lxO.
	.....''''..........,:ld;
	           .';;;:::;,,.x,
	      ..'''.            0Xxoc:,.  ...
	  ....                ,ONkc;,;cokOdc',.
	 .                   OMo           ':00€
        	            dMc               :OO;
                	    0M.                 .:o.
	                    ;Wd
        	             ;XO,
                	       ,d0Odlc;,..
	                           ..',;:cdOOd::,.
        	                            .:d;.':;.
                	                       'd,  .'
                        	                 ;l   ..
                                	          .o
                                        	    c
        	                                    .'
	                                             . by BOFKAN""")
def code():
	os.system("clear")
	hokok()
	url = str(input("ENTER WEBSITE : "))
	code = requests.get(url+"/robots.txt")
	url2 = requests.get(url)
	a = code.text
	c = eval(str(url2.headers))
	print(" ")
	print("--scaning--/ "+red+url)
	print(blue+"-----------------------------------------------------")
	print("[!]   HTTP Response Code : "+red+str(url2.status_code)+blue)
	print("[!]   encode : "+red+str(url2.encoding)+blue)
	print("[!]   Server : "+red+str(c['Server'])+blue)
	print("[!]   Connection : "+red+str(c['Connection']))
	print(blue+"-----------------------------------------------------"+green) 
	print(a)
def Scan():
	os.system("clear")
	hokok()
	ip = input(blue+"ENTER IP OR WEBSITE ~~> "+red)
	os.system("nmap -sV -T4 "+ip)
def amebo():
	os.system("clear")
	hokok()
	print("""
	"""+red+"""--1--/"""+blue+""" website code
	"""+red+"""--2--/"""+blue+""" port/servers
	
	"""+red+"""--0--/"""+blue+"""exit""")
	a = input(green+"--> "+red)
	if a == "1":
		code()
	elif a == "2":
		Scan()
	elif a == "0":
		os.system("clear")
		print("bye :)")
	else:
		amebo()

def password():
	os.system("clear")
	hokok()
	password = input(red+"ENTER PASSWORD : "+black)
	if password == "BoFkAn":
		amebo()
	else:
		print(blue+"wrong password ... ")
		time.sleep(3)
		os.system("python amebo.py")


